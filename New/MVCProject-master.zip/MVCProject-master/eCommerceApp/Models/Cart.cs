﻿namespace eCommerceApp.Models
{
    public class Cart
    {
        public string CartID { get; set; }
        public string CartName { get; set;}
        public int Quantity { get; set; }

        
    }
}
